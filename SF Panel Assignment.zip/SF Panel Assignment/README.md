Can't express my gratitude enough to allow me pursuinng this opportunity with finDoc for the position of Salesforce Product Engineer to take part in such an exciting assignment to work on with.

The requirements were nicely organized and made me think and brainstorm as there are multiple open aspects to progress with the hands-on challenge.

Grateful if you would look through my humble solution and custom code, in a few cases I have reused a few methods that were already present with the project that you shared.

It took me almost 4 hours 30 minutes to wrap up this assignment, of course there are ample scope of enhancing and scaling the code that I wrote,. Nonetheless, I'd be able to touch upon all such aspects during my presentation with the panel.

Once more, thank you so much for offering to be a part of your evaluation process. 