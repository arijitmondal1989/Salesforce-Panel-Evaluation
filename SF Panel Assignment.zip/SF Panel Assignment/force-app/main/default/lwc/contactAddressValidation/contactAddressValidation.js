import { LightningElement, api, track } from 'lwc';
import multipleContactAddress from '@salesforce/apex/ContactAddressValidation.multipleContactAddress';
import getValidatedContacts from '@salesforce/apex/ContactAddressValidation.getValidatedContacts';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { CloseActionScreenEvent } from 'lightning/actions';

export default class ValidateContactAddresses extends LightningElement {
    @api recordId;
    @track isLoading = false;
    @track contacts = [];

    columns = [
        { label: 'Name', fieldName: 'Name' },
        { label: 'Street', fieldName: 'MailingStreet' },
        { label: 'City', fieldName: 'MailingCity' },
        { label: 'State', fieldName: 'MailingState' },
        { label: 'Zip Code', fieldName: 'MailingPostalCode' },
        { label: 'Country', fieldName: 'MailingCountry' },
        { label: 'Verified?', fieldName: 'AddressValid__c' },
    ];

    handleValidate() {
        this.isLoading = true;

        multipleContactAddress({ accountId: this.recordId })
            .then(result => {
                this.message = result;
                this.showToast('Success', result, 'success');
                this.loadContacts(); 
            })
            .catch(error => {
                console.error('Validation error', error);
                this.showToast('Error', error.body?.message || 'Failed to validate addresses.', 'error');
                this.isLoading = false;
            });
    }

    loadContacts() {
        getValidatedContacts({ accountId: this.recordId })
            .then(result => {
                this.contacts = result;
                this.isLoading = false;
            })
            .catch(error => {
                this.isLoading = false;
                console.error('Load contacts error', error);
                this.showToast('Error', 'Failed to load contacts', 'error');
            });
    }

    showToast(title, message, variant) {
        this.dispatchEvent(
            new ShowToastEvent({
                title,
                message,
                variant
            })
        );
    }

    connectedCallback() {
        this.loadContacts(); // Load contacts on component load
    }
}